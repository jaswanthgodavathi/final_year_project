import React, { Component } from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "../index.css";

export default class Welcome extends Component {
  constructor(props) {
    super(props);

    this.state = {
      username: '',
      inputValue: '',
      stats: null,
    };
  }

  componentDidMount() {
    let getUserDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    if (getUserDetails) {
      this.setState({
        username: getUserDetails.username
      });
    } else {
      this.props.history.push('/signup');
    }
  }

  logOut = (e) => {
    e.preventDefault();
    this.props.history.push('/signin');
  }

  handleStatistics = (e) => {
    e.preventDefault();
    const { inputValue } = this.state;

    // Replace 'your-google-colab-url' with your actual Google Colab API URL
    fetch(`http://your-google-colab-url/stats?input=${inputValue}`)
      .then(response => response.json())
      .then(data => {
        this.setState({ stats: data.stats }); // Adjust based on your response format
      })
      .catch(error => {
        console.error("Error fetching stats:", error);
      });
  };

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand-md navbar-dark bg-dark">
          {/* Navbar content */}
        </nav>
        <main role="main">
          <div className="jumbotron text-center">
            <h1 className="display-4 animated bounce">Hello, {this.state.username}!</h1>
            <p className="lead animated fadeIn">Welcome to Smart Electricity Management.</p>
          </div>

          <div className="container">
            {/* Input form for statistics */}
            <form onSubmit={this.handleStatistics}>
              <h2 className="text-center">Input Data for Statistics</h2>
              <input 
                type="number" 
                placeholder="Enter a value" 
                className="form-control mb-2" 
                value={this.state.inputValue} 
                onChange={(e) => this.setState({ inputValue: e.target.value })} 
                required 
              />
              <button type="submit" className="btn btn-primary">Get Stats</button>
            </form>

            {/* Display the statistics */}
            {this.state.stats !== null && (
              <div className="stats-display">
                <h3>Statistics:</h3>
                <p>{this.state.stats}</p>
              </div>
            )}
          </div>
        </main>

        <footer className="container text-center">
          <p>&copy; Smart Energy Management 2024</p>
        </footer>
      </div>
    );
  }
}
